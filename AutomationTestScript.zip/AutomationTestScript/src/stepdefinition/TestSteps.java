package stepdefinition;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;


public class TestSteps {

	WebDriver driver ;
	

	@Given("^Customer is on shopping website$")
	public void customer_is_on_shopping_website() throws Throwable {
		String path = System.getProperty("user.dir");
		System.out.println(path); 
		System.setProperty("webdriver.chrome.driver", path+"\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://testscriptdemo.com");
	}


	@When("^I add four different products to my wish list$")
	public void i_add_four_different_products_to_my_wish_list() throws Throwable {
		WebElement item1 = driver.findElement(By.xpath("//a[@data-product-id='17']"));
		item1.click();

		Thread.sleep(4000);

		WebElement item2 = driver.findElement(By.xpath("//a[@data-product-id='14']"));
		item2.click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");

		Thread.sleep(4000);

		WebElement item3 = driver.findElement(By.xpath("//a[@data-product-id='18']"));
		item3.click();

		Thread.sleep(4000);

		WebElement item4 = driver.findElement(By.xpath("//a[@data-product-id='19']"));
		item4.click();

		Thread.sleep(4000);
	}

	@And("^I view my wishlist table$")
	public void i_view_my_wishlist_table() throws Throwable {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)", "");

		Thread.sleep(4000);

		WebElement wishListTable = driver.findElement(By.xpath("//a[@title='Wishlist']"));
		wishListTable.click();

		Thread.sleep(4000);
	}

	@Then("^I find total four selected items in my wishlist$")
	public void i_find_total_four_selected_items_in_my_wishlist() throws Throwable {
		List<String> checkItems = new ArrayList<String>();
		checkItems.add("Black pants");
		checkItems.add("Modern");
		checkItems.add("Hard top");
		checkItems.add("Polo T-shirt");
		
		List<WebElement> selectedItems =  driver.findElements(By.xpath("//td[@class='product-name']"));
		if(selectedItems!=null) {
			for(int item=0;item<=selectedItems.size()-1;item++) {
				selectedItems.get(item).equals(checkItems.get(item));
			}
		}
		assertTrue("Test pass",true);
	}

	@When("^I search for lowest price product$")
	public void i_search_for_lowest_price_product() throws Throwable {
		WebElement searchText = driver.findElement(By.cssSelector("input[type='search']"));
		searchText.sendKeys("Modern");

		Thread.sleep(4000);

		WebElement searchButton = driver.findElement(By.cssSelector("input[value='Search']"));
		searchButton.click();

		Thread.sleep(4000);
	}

	@And("^I am able to add the lowest price item to my cart$")
	public void i_am_able_to_add_the_lowest_price_item_to_my_cart() throws Throwable {

		WebElement lowestPriceItem = driver.findElement(By.xpath("//a[@title='Modern']"));
		lowestPriceItem.click();

		Thread.sleep(4000);

		WebElement addToCart = driver.findElement(By.xpath("//button[@name='add-to-cart']"));
		addToCart.click();

		Thread.sleep(4000);
	}

	@Then("^I am able to verify the item in my cart$")
	public void i_am_able_to_verify_the_item_in_my_cart() throws Throwable {
		WebElement cart = driver.findElement(By.xpath("//a[@title='Cart']"));
		cart.click();

		Thread.sleep(4000);

		List<WebElement> cartList = driver.findElements(By.xpath("//td[@class='product-name']"));
		String cartListitemName= "Modern";
		if(cartList != null && cartListitemName.equals(cartList.get(0).getText())) {
			assertTrue("Test Pass", true);
		}
		driver.close();
	}
}
